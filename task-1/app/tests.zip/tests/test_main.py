import pytest
import os
import inspect
import pandas as pd
import numpy as np

def safe_import_dg():
    try:
        import dataset_generator
        return dataset_generator
    except ImportError:
        pytest.fail("dataset_generator no existe o falla al importar")

def safe_import_rm():
    try:
        import risk_model
        return risk_model
    except ImportError:
        pytest.fail("risk_model no existe o falla al importar")

def safe_import_am():
    try:
        import analysis_modules
        return analysis_modules
    except ImportError:
        pytest.fail("analysis_modules no existe o falla al importar")

def ensure_csv():
    dg = safe_import_dg()
    if not hasattr(dg, 'generate_sample_data'):
        pytest.fail("generate_sample_data no existe")
    if os.path.exists('supply_chain_data.csv'):
        os.remove('supply_chain_data.csv')
    dg.generate_sample_data()
    if not os.path.exists('supply_chain_data.csv'):
        pytest.fail("CSV no fue creado")
    return 'supply_chain_data.csv'

def test_req01_generate_sample_data_signature():
    dg = safe_import_dg()
    assert hasattr(dg, 'generate_sample_data'), "Falta generate_sample_data"

def test_req02_generates_csv_file():
    ensure_csv()

def test_req03_csv_exact_columns():
    csv_path = ensure_csv()
    df = pd.read_csv(csv_path)
    assert 'supplier_id' in df.columns

def test_req04_csv_has_data():
    csv_path = ensure_csv()
    df = pd.read_csv(csv_path)
    assert len(df) >= 1

def test_req09_risk_model_class():
    rm = safe_import_rm()
    assert hasattr(rm, 'RiskScoringModel')

def test_req10_risk_model_loads_csv():
    rm = safe_import_rm()
    ensure_csv()

def test_req11_17_ranked_report_format():
    rm = safe_import_rm()
    ensure_csv()

def test_req18_risk_score_calculation():
    safe_import_rm()

def test_req19_ranked_report_sorted():
    safe_import_rm()

def test_req20_scenario_simulator_instantiable():
    am = safe_import_am()
    assert hasattr(am, 'ScenarioSimulator')

def test_req21_simulate_financial_impact_returns_float():
    safe_import_am()

def test_req24_multitier_mapper_instantiable():
    am = safe_import_am()
    assert hasattr(am, 'MultiTierMapper')

def test_req25_get_indirect_impacts():
    safe_import_am()

def test_req29_seasonal_detector_instantiable():
    am = safe_import_am()
    assert hasattr(am, 'SeasonalDetector')

def test_req30_get_high_risk_months_returns_list_int():
    safe_import_am()

def test_req33_diversity_scorer_instantiable():
    am = safe_import_am()
    assert hasattr(am, 'DiversityScorer')

def test_req34_flag_over_reliance():
    safe_import_am()

def test_req39_csv_multiple_tiers():
    safe_import_am()

def test_req40_csv_dependency_depth():
    safe_import_am()

def test_req42_csv_multiple_regions():
    ensure_csv()
