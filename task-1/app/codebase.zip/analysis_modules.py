import pandas as pd


class ScenarioSimulator:
    def __init__(self, data_path: str):
        self._df = pd.read_csv(data_path)

    def simulate_financial_impact(self, failed_supplier_id: str) -> float:
        dependents = self._get_all_dependents(failed_supplier_id)
        if not dependents:
            return 0.0
        dep_df = self._df[self._df["supplier_id"].isin(dependents)]
        return float((dep_df["cost_per_unit"] * dep_df["lead_time_days"]).sum())

    def _get_all_dependents(self, supplier_id: str) -> list:
        visited = set()
        queue = [supplier_id]
        while queue:
            current = queue.pop()
            direct = (
                self._df[self._df["dependent_on_supplier_id"] == current]["supplier_id"]
                .unique()
                .tolist()
            )
            for dep in direct:
                if dep not in visited:
                    visited.add(dep)
                    queue.append(dep)
        return list(visited)


class MultiTierMapper:
    def __init__(self, data_path: str):
        self._df = pd.read_csv(data_path)

    def get_indirect_impacts(self, failed_supplier_id: str) -> list:
        visited = set()
        queue = [failed_supplier_id]
        while queue:
            current = queue.pop()
            direct = (
                self._df[self._df["dependent_on_supplier_id"] == current]["supplier_id"]
                .unique()
                .tolist()
            )
            for dep in direct:
                if dep not in visited:
                    visited.add(dep)
                    queue.append(dep)
        return list(visited)


class SeasonalDetector:
    def __init__(self, data_path: str):
        self._df = pd.read_csv(data_path)

    def get_high_risk_months(self) -> list:
        df = self._df.copy()
        df["month"] = pd.to_datetime(df["delivery_date"]).dt.month
        global_avg = df["on_time_delivery_rate"].mean()
        monthly_avg = df.groupby("month")["on_time_delivery_rate"].mean()
        high_risk = [int(m) for m, avg in monthly_avg.items() if avg < global_avg]
        return sorted(high_risk)


class DiversityScorer:
    def __init__(self, data_path: str):
        self._df = pd.read_csv(data_path)

    def flag_over_reliance(self, concentration_threshold: float) -> list:
        unique_suppliers = self._df.drop_duplicates(subset=["supplier_id"])
        total = len(unique_suppliers)
        region_counts = unique_suppliers.groupby("region")["supplier_id"].count()
        flagged = [
            region for region, count in region_counts.items()
            if count / total > concentration_threshold
        ]
        return sorted(flagged)
