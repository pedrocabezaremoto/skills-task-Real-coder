import numpy as np
import pandas as pd


def generate_sample_data():
    rng = np.random.default_rng(42)

    suppliers = [
        {"supplier_id": "S001", "supplier_name": "Alpha Corp",  "region": "Asia",     "tier": 1, "dependent_on_supplier_id": ""},
        {"supplier_id": "S002", "supplier_name": "Beta Ltd",    "region": "Europe",   "tier": 1, "dependent_on_supplier_id": ""},
        {"supplier_id": "S003", "supplier_name": "Gamma Inc",   "region": "Asia",     "tier": 2, "dependent_on_supplier_id": "S001"},
        {"supplier_id": "S004", "supplier_name": "Delta Co",    "region": "Americas", "tier": 2, "dependent_on_supplier_id": "S002"},
        {"supplier_id": "S005", "supplier_name": "Epsilon SA",  "region": "Asia",     "tier": 3, "dependent_on_supplier_id": "S003"},
        {"supplier_id": "S006", "supplier_name": "Zeta GmbH",   "region": "Europe",   "tier": 1, "dependent_on_supplier_id": ""},
        {"supplier_id": "S007", "supplier_name": "Eta Corp",    "region": "Americas", "tier": 2, "dependent_on_supplier_id": "S006"},
    ]

    records = []
    for sup in suppliers:
        for month in range(1, 13):
            for _ in range(2):
                day = int(rng.integers(1, 28))
                date_str = f"2023-{month:02d}-{day:02d}"
                otr = round(float(rng.uniform(0.4, 1.0)), 4)
                lead = int(rng.integers(5, 45))
                cost = round(float(rng.uniform(10.0, 500.0)), 2)
                records.append({
                    "supplier_id": sup["supplier_id"],
                    "supplier_name": sup["supplier_name"],
                    "region": sup["region"],
                    "tier": sup["tier"],
                    "dependent_on_supplier_id": sup["dependent_on_supplier_id"],
                    "delivery_date": date_str,
                    "on_time_delivery_rate": otr,
                    "lead_time_days": lead,
                    "cost_per_unit": cost,
                })

    df = pd.DataFrame(records, columns=[
        "supplier_id", "supplier_name", "region", "tier",
        "dependent_on_supplier_id", "delivery_date",
        "on_time_delivery_rate", "lead_time_days", "cost_per_unit",
    ])
    df.to_csv("supply_chain_data.csv", index=False)
