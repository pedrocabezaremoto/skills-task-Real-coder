import pandas as pd


class RiskScoringModel:
    def __init__(self, data_path: str):
        self._df = pd.read_csv(data_path)

    def generate_ranked_report(self) -> list:
        agg = self._df.groupby("supplier_id").agg(
            on_time_delivery_rate=("on_time_delivery_rate", "mean"),
            lead_time_days=("lead_time_days", "mean"),
            cost_per_unit=("cost_per_unit", "mean"),
        ).reset_index()

        max_lead = agg["lead_time_days"].max()
        max_cost = agg["cost_per_unit"].max()

        agg["risk_score"] = (
            0.5 * (1.0 - agg["on_time_delivery_rate"])
            + 0.3 * (agg["lead_time_days"] / max_lead)
            + 0.2 * (agg["cost_per_unit"] / max_cost)
        )

        agg = agg.sort_values("risk_score", ascending=False).reset_index(drop=True)

        report = []
        for _, row in agg.iterrows():
            report.append({
                "supplier_id": str(row["supplier_id"]),
                "risk_score": float(row["risk_score"]),
                "mitigation_actions": [
                    "Increase safety stock levels to buffer against supply disruptions.",
                    "Identify and qualify alternative suppliers to reduce single-vendor risk.",
                ],
            })
        return report
